# acme-dns Helm chart

Requires Kubernetes 1.25+ and Helm 3. Follow the [README installation steps](../../README.md#helm).

## Values

See [values.yaml](values.yaml) for all defaults, resources and scheduling options.

| Value | Purpose |
| --- | --- |
| `image.repository` | Default `cubesystems/acme-dns` |
| `image.tag` / `image.digest` | Default tag is `appVersion`; digest takes precedence |
| `cloudflare.existingSecret` | Required Secret; default key is `CF_DNS_API_TOKEN` |
| `config.zoneId`, `config.zoneName`, `config.clients` | Client configuration |
| `config.existingConfigMap` | Name of a ConfigMap containing a `clients.json` key |
| `service.type`, `service.port` | Default `ClusterIP`, port `80` → container `8080` |

Optional ingress for an existing controller:

```yaml
ingress:
  enabled: true
  className: your-ingress-class
  host: dns-api.example.com
```

Configure HTTPS through your existing proxy or `ingress.tls`.

## Updates

During an update, Helm stops the old container before starting the new one, causing brief downtime. Keep one copy running.

Changing config in Helm values restarts the container. After changing an external ConfigMap or Secret, set a new `podAnnotations.configRevision` value and run `helm upgrade` to restart it.

For branch images, use `image.pullPolicy: Always` and change `podAnnotations.imageRevision` with each `helm upgrade`. Publishing a new image under the same tag does not restart the container. Alternatively, set `image.tag` to the new build's `sha-<full-commit-sha>` tag.
